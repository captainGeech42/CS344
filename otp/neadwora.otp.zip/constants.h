#ifndef CONSTANTS_H
#define CONSTANTS_H

#define CONNECTION_BACKLOG 5
#define CONNECTION_GOOD "pass"
#define CONNECTION_BAD "fail"
#define BUFFER_BASE 1024

#endif