these errors for the bad plaintext are both expected:

    got a bad character to send, exiting
    received a bad character, exiting

the client generates the first one, and the server generates the second one. they are both for the same input (plaintext5).
