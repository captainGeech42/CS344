#ifndef KEYGEN_H
#define KEYGEN_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(int, char **);

#endif